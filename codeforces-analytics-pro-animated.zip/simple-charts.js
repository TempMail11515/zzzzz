// Simple Charts Library - Native Canvas Implementation with Animations
// Replaces Chart.js to avoid loading issues

class SimpleChart {
    constructor(canvas, config) {
        this.canvas = canvas;
        this.ctx = canvas.getContext('2d');
        this.config = config;
        this.width = canvas.width || 400;
        this.height = canvas.height || 300;
        
        // Animation properties
        this.animationProgress = 0;
        this.animationDuration = 1500; // 1.5 seconds
        this.startTime = null;
        this.isAnimating = true;
        
        // Interactive properties
        this.hoveredIndex = -1;
        this.tooltipVisible = false;
        this.tooltipX = 0;
        this.tooltipY = 0;
        this.tooltipText = '';
        
        // Set canvas size
        canvas.width = this.width;
        canvas.height = this.height;
        
        // Add event listeners for interactivity
        this.addEventListeners();
        
        // Start animation
        this.animate();
    }
    
    addEventListeners() {
        this.canvas.addEventListener('mousemove', (e) => {
            const rect = this.canvas.getBoundingClientRect();
            const x = e.clientX - rect.left;
            const y = e.clientY - rect.top;
            this.handleMouseMove(x, y);
        });
        
        this.canvas.addEventListener('mouseleave', () => {
            this.hoveredIndex = -1;
            this.tooltipVisible = false;
            this.redraw();
        });
        
        this.canvas.addEventListener('click', (e) => {
            const rect = this.canvas.getBoundingClientRect();
            const x = e.clientX - rect.left;
            const y = e.clientY - rect.top;
            this.handleClick(x, y);
        });
    }
    
    animate() {
        const now = Date.now();
        if (!this.startTime) this.startTime = now;
        
        const elapsed = now - this.startTime;
        this.animationProgress = Math.min(elapsed / this.animationDuration, 1);
        
        // Easing function (ease-out)
        this.animationProgress = 1 - Math.pow(1 - this.animationProgress, 3);
        
        this.draw();
        
        if (this.animationProgress < 1) {
            requestAnimationFrame(() => this.animate());
        } else {
            this.isAnimating = false;
        }
    }
    
    redraw() {
        if (!this.isAnimating) {
            this.draw();
        }
    }
    
    draw() {
        this.ctx.clearRect(0, 0, this.width, this.height);
        
        switch (this.config.type) {
            case 'bar':
                this.drawBarChart();
                break;
            case 'line':
                this.drawLineChart();
                break;
            case 'pie':
                this.drawPieChart();
                break;
            default:
                this.drawErrorMessage();
        }
    }
    
    drawBarChart() {
        const data = this.config.data;
        const labels = data.labels;
        const datasets = data.datasets;
        
        if (!labels || !datasets || labels.length === 0) {
            this.drawNoDataMessage();
            return;
        }
        
        const padding = 40;
        const chartWidth = this.width - 2 * padding;
        const chartHeight = this.height - 2 * padding - 60; // Extra space for labels
        
        // Find max value
        let maxValue = 0;
        datasets.forEach(dataset => {
            maxValue = Math.max(maxValue, ...dataset.data);
        });
        
        if (maxValue === 0) maxValue = 100; // Default max for empty data
        
        const barWidth = chartWidth / (labels.length * datasets.length + labels.length - 1) * 0.8;
        const groupWidth = chartWidth / labels.length;
        
        // Draw axes
        this.ctx.strokeStyle = '#333';
        this.ctx.lineWidth = 1;
        this.ctx.beginPath();
        this.ctx.moveTo(padding, padding);
        this.ctx.lineTo(padding, padding + chartHeight);
        this.ctx.lineTo(padding + chartWidth, padding + chartHeight);
        this.ctx.stroke();
        
        // Draw bars with animation
        labels.forEach((label, labelIndex) => {
            datasets.forEach((dataset, datasetIndex) => {
                const value = dataset.data[labelIndex] || 0;
                const fullBarHeight = (value / maxValue) * chartHeight;
                const animatedBarHeight = fullBarHeight * this.animationProgress;
                
                const x = padding + labelIndex * groupWidth + datasetIndex * barWidth;
                const y = padding + chartHeight - animatedBarHeight;
                
                // Highlight if hovered
                const isHovered = this.hoveredIndex === labelIndex;
                let fillColor = dataset.backgroundColor || this.getColor(datasetIndex);
                if (isHovered) {
                    fillColor = this.lightenColor(fillColor, 20);
                }
                
                this.ctx.fillStyle = fillColor;
                this.ctx.fillRect(x, y, barWidth, animatedBarHeight);
                
                // Draw value on top of bar (only when animation is complete)
                if (value > 0 && this.animationProgress > 0.8) {
                    this.ctx.fillStyle = '#333';
                    this.ctx.font = '10px Arial';
                    this.ctx.textAlign = 'center';
                    const alpha = (this.animationProgress - 0.8) / 0.2;
                    this.ctx.globalAlpha = alpha;
                    this.ctx.fillText(value.toString(), x + barWidth/2, y - 5);
                    this.ctx.globalAlpha = 1;
                }
                
                // Store bar bounds for interactivity
                if (!this.barBounds) this.barBounds = [];
                this.barBounds[labelIndex] = { x, y: padding, width: barWidth, height: chartHeight, value, label };
            });
            
            // Draw label with fade-in animation
            this.ctx.fillStyle = '#333';
            this.ctx.font = '10px Arial';
            this.ctx.textAlign = 'center';
            this.ctx.globalAlpha = this.animationProgress;
            this.ctx.save();
            this.ctx.translate(padding + labelIndex * groupWidth + groupWidth/2, this.height - 20);
            this.ctx.rotate(-Math.PI/4);
            this.ctx.fillText(label.length > 12 ? label.substring(0, 12) + '...' : label, 0, 0);
            this.ctx.restore();
            this.ctx.globalAlpha = 1;
        });
        
        // Draw legend
        this.drawLegend(datasets);
    }
    
    drawLineChart() {
        const data = this.config.data;
        const labels = data.labels;
        const datasets = data.datasets;
        
        if (!labels || !datasets || labels.length === 0) {
            this.drawNoDataMessage();
            return;
        }
        
        const padding = 40;
        const chartWidth = this.width - 2 * padding;
        const chartHeight = this.height - 2 * padding - 40;
        
        // Find max and min values
        let maxValue = -Infinity;
        let minValue = Infinity;
        datasets.forEach(dataset => {
            dataset.data.forEach(value => {
                maxValue = Math.max(maxValue, value);
                minValue = Math.min(minValue, value);
            });
        });
        
        if (maxValue === minValue) {
            maxValue += 100;
            minValue -= 100;
        }
        
        const pointSpacing = chartWidth / (labels.length - 1);
        
        // Draw axes
        this.ctx.strokeStyle = '#333';
        this.ctx.lineWidth = 1;
        this.ctx.beginPath();
        this.ctx.moveTo(padding, padding);
        this.ctx.lineTo(padding, padding + chartHeight);
        this.ctx.lineTo(padding + chartWidth, padding + chartHeight);
        this.ctx.stroke();
        
        // Draw lines
        datasets.forEach((dataset, datasetIndex) => {
            this.ctx.strokeStyle = dataset.borderColor || this.getColor(datasetIndex);
            this.ctx.lineWidth = 2;
            this.ctx.beginPath();
            
            dataset.data.forEach((value, index) => {
                const x = padding + index * pointSpacing;
                const y = padding + chartHeight - ((value - minValue) / (maxValue - minValue)) * chartHeight;
                
                if (index === 0) {
                    this.ctx.moveTo(x, y);
                } else {
                    this.ctx.lineTo(x, y);
                }
            });
            
            this.ctx.stroke();
            
            // Draw points
            this.ctx.fillStyle = dataset.borderColor || this.getColor(datasetIndex);
            dataset.data.forEach((value, index) => {
                const x = padding + index * pointSpacing;
                const y = padding + chartHeight - ((value - minValue) / (maxValue - minValue)) * chartHeight;
                
                this.ctx.beginPath();
                this.ctx.arc(x, y, 3, 0, 2 * Math.PI);
                this.ctx.fill();
            });
        });
        
        // Draw labels
        this.ctx.fillStyle = '#333';
        this.ctx.font = '10px Arial';
        this.ctx.textAlign = 'center';
        labels.forEach((label, index) => {
            const x = padding + index * pointSpacing;
            this.ctx.fillText(
                label.length > 8 ? `${index + 1}` : label, 
                x, 
                this.height - 10
            );
        });
        
        this.drawLegend(datasets);
    }
    
    drawPieChart() {
        const data = this.config.data;
        const labels = data.labels;
        const values = data.datasets[0].data;
        const colors = data.datasets[0].backgroundColor;
        
        if (!labels || !values || labels.length === 0) {
            this.drawNoDataMessage();
            return;
        }
        
        const centerX = this.width / 2;
        const centerY = this.height / 2 - 20;
        const radius = Math.min(this.width, this.height) / 3;
        
        const total = values.reduce((sum, value) => sum + value, 0);
        
        if (total === 0) {
            this.drawNoDataMessage();
            return;
        }
        
        let currentAngle = -Math.PI / 2; // Start from top
        
        values.forEach((value, index) => {
            const sliceAngle = (value / total) * 2 * Math.PI;
            
            // Draw slice
            this.ctx.fillStyle = colors[index] || this.getColor(index);
            this.ctx.beginPath();
            this.ctx.moveTo(centerX, centerY);
            this.ctx.arc(centerX, centerY, radius, currentAngle, currentAngle + sliceAngle);
            this.ctx.closePath();
            this.ctx.fill();
            
            // Draw label if slice is big enough
            if (sliceAngle > 0.1) {
                const labelAngle = currentAngle + sliceAngle / 2;
                const labelX = centerX + Math.cos(labelAngle) * (radius * 0.7);
                const labelY = centerY + Math.sin(labelAngle) * (radius * 0.7);
                
                this.ctx.fillStyle = '#fff';
                this.ctx.font = 'bold 10px Arial';
                this.ctx.textAlign = 'center';
                this.ctx.fillText(value.toString(), labelX, labelY);
            }
            
            currentAngle += sliceAngle;
        });
        
        // Draw legend
        this.drawPieLegend(labels, colors);
    }
    
    drawLegend(datasets) {
        const legendY = 10;
        let legendX = this.width - 150;
        
        datasets.forEach((dataset, index) => {
            // Draw color box
            this.ctx.fillStyle = dataset.backgroundColor || dataset.borderColor || this.getColor(index);
            this.ctx.fillRect(legendX, legendY + index * 20, 15, 15);
            
            // Draw label
            this.ctx.fillStyle = '#333';
            this.ctx.font = '12px Arial';
            this.ctx.textAlign = 'left';
            this.ctx.fillText(dataset.label || `Dataset ${index + 1}`, legendX + 20, legendY + index * 20 + 12);
        });
    }
    
    drawPieLegend(labels, colors) {
        const legendY = this.height - 60;
        const legendItemWidth = 120;
        const itemsPerRow = Math.floor(this.width / legendItemWidth);
        
        labels.forEach((label, index) => {
            const row = Math.floor(index / itemsPerRow);
            const col = index % itemsPerRow;
            const x = 10 + col * legendItemWidth;
            const y = legendY + row * 20;
            
            // Draw color box
            this.ctx.fillStyle = colors[index] || this.getColor(index);
            this.ctx.fillRect(x, y, 12, 12);
            
            // Draw label
            this.ctx.fillStyle = '#333';
            this.ctx.font = '10px Arial';
            this.ctx.textAlign = 'left';
            const shortLabel = label.length > 15 ? label.substring(0, 15) + '...' : label;
            this.ctx.fillText(shortLabel, x + 15, y + 10);
        });
    }
    
    drawNoDataMessage() {
        this.ctx.fillStyle = '#666';
        this.ctx.font = '16px Arial';
        this.ctx.textAlign = 'center';
        this.ctx.fillText('No data available', this.width / 2, this.height / 2);
    }
    
    drawErrorMessage() {
        this.ctx.fillStyle = '#e74c3c';
        this.ctx.font = '14px Arial';
        this.ctx.textAlign = 'center';
        this.ctx.fillText('Chart type not supported', this.width / 2, this.height / 2);
    }
    
    getColor(index) {
        const colors = [
            '#FF6384', '#36A2EB', '#FFCE56', '#4BC0C0', '#9966FF',
            '#FF9F40', '#FF6384', '#C9CBCF', '#4BC0C0', '#36A2EB'
        ];
        return colors[index % colors.length];
    }
    
    lightenColor(color, percent) {
        // Convert hex/rgba to rgb values and lighten
        if (color.startsWith('#')) {
            const num = parseInt(color.slice(1), 16);
            const r = Math.min(255, Math.floor((num >> 16) + ((255 - (num >> 16)) * percent / 100)));
            const g = Math.min(255, Math.floor(((num >> 8) & 0x00FF) + ((255 - ((num >> 8) & 0x00FF)) * percent / 100)));
            const b = Math.min(255, Math.floor((num & 0x0000FF) + ((255 - (num & 0x0000FF)) * percent / 100)));
            return `rgb(${r}, ${g}, ${b})`;
        }
        return color; // Return original if can't parse
    }
    
    handleMouseMove(x, y) {
        if (this.config.type === 'bar' && this.barBounds) {
            let foundHover = false;
            this.barBounds.forEach((bounds, index) => {
                if (bounds && x >= bounds.x && x <= bounds.x + bounds.width &&
                    y >= bounds.y && y <= bounds.y + bounds.height) {
                    if (this.hoveredIndex !== index) {
                        this.hoveredIndex = index;
                        this.tooltipX = x;
                        this.tooltipY = y;
                        this.tooltipText = `${bounds.label}: ${bounds.value}`;
                        this.tooltipVisible = true;
                        this.redraw();
                    }
                    foundHover = true;
                }
            });
            
            if (!foundHover && this.hoveredIndex !== -1) {
                this.hoveredIndex = -1;
                this.tooltipVisible = false;
                this.redraw();
            }
        }
    }
    
    handleClick(x, y) {
        // Handle click events for interactivity
        console.log(`Chart clicked at: ${x}, ${y}`);
        // Could be extended to show detailed modal or drill-down
    }
    
    drawTooltip() {
        if (!this.tooltipVisible) return;
        
        this.ctx.save();
        this.ctx.fillStyle = 'rgba(0, 0, 0, 0.8)';
        this.ctx.fillRect(this.tooltipX + 10, this.tooltipY - 30, 100, 20);
        this.ctx.fillStyle = 'white';
        this.ctx.font = '12px Arial';
        this.ctx.fillText(this.tooltipText, this.tooltipX + 15, this.tooltipY - 15);
        this.ctx.restore();
    }
}

// Global Chart object to mimic Chart.js API
window.Chart = SimpleChart;